Copy all mipmap-* folders into app/src/main/res/.
In app/src/main/AndroidManifest.xml, add these attributes to the existing <application> tag:
android:icon="@mipmap/ic_launcher"
android:roundIcon="@mipmap/ic_launcher"
Do not replace the whole manifest file.
