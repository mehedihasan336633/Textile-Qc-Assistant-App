package com.textileqc.assistant

import android.app.Activity
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.os.Environment
import android.provider.MediaStore
import android.webkit.*
import android.widget.FrameLayout
import android.widget.Toast
import androidx.core.content.FileProvider
import java.io.File
import java.io.FileOutputStream
import android.util.Base64

class MainActivity : Activity() {
    private var fileCallback: ValueCallback<Array<Uri>>? = null
    private var cameraUri: Uri? = null
    private val pickFile = 1001

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val web = WebView(this)
        web.settings.javaScriptEnabled = true
        web.settings.domStorageEnabled = true
        web.settings.allowFileAccess = true
        web.settings.allowContentAccess = true
        web.settings.javaScriptCanOpenWindowsAutomatically = true
        web.addJavascriptInterface(DownloadBridge(), "AndroidDownloads")
        web.webChromeClient = object : WebChromeClient() {
            override fun onShowFileChooser(v: WebView?, callback: ValueCallback<Array<Uri>>?, params: FileChooserParams?): Boolean {
                fileCallback?.onReceiveValue(null)
                fileCallback = callback
                val gallery = Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
                    addCategory(Intent.CATEGORY_OPENABLE)
                    type = params?.acceptTypes?.firstOrNull()?.takeIf { it.isNotBlank() } ?: "image/*"
                    putExtra(Intent.EXTRA_ALLOW_MULTIPLE, params?.mode == FileChooserParams.MODE_OPEN_MULTIPLE)
                }
                val camera = try {
                    val dir = File(cacheDir, "camera").apply { mkdirs() }
                    val photo = File.createTempFile("qc_photo_", ".jpg", dir)
                    cameraUri = FileProvider.getUriForFile(this@MainActivity, "$packageName.fileprovider", photo)
                    Intent(MediaStore.ACTION_IMAGE_CAPTURE).apply {
                        putExtra(MediaStore.EXTRA_OUTPUT, cameraUri)
                        addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_WRITE_URI_PERMISSION)
                    }
                } catch (_: Exception) { null }
                val chooser = Intent.createChooser(gallery, "Choose photo")
                if (camera != null) chooser.putExtra(Intent.EXTRA_INITIAL_INTENTS, arrayOf(camera))
                return try { startActivityForResult(chooser, pickFile); true } catch (_: Exception) { fileCallback = null; false }
            }
        }
        web.webViewClient = WebViewClient()
        web.loadUrl("file:///android_asset/index.html")
        setContentView(web, FrameLayout.LayoutParams(-1, -1))
    }

    @Deprecated("Deprecated in Android")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == pickFile) {
            val result: Array<Uri>? = if (resultCode == Activity.RESULT_OK) {
                val picked = WebChromeClient.FileChooserParams.parseResult(resultCode, data)
                when {
                    !picked.isNullOrEmpty() -> picked
                    cameraUri != null -> arrayOf(cameraUri!!)
                    else -> null
                }
            } else null
            fileCallback?.onReceiveValue(result)
            fileCallback = null
            cameraUri = null
        }
    }

    inner class DownloadBridge {
        @JavascriptInterface fun saveBase64(base64: String, fileName: String, mimeType: String): String {
            return try {
                val safeName = fileName.replace(Regex("[^A-Za-z0-9._-]"), "_").ifBlank { "QC_Report" }
                val bytes = Base64.decode(base64.substringAfter(","), Base64.DEFAULT)
                if (android.os.Build.VERSION.SDK_INT >= 29) {
                    val values = android.content.ContentValues().apply {
                        put(MediaStore.MediaColumns.DISPLAY_NAME, safeName)
                        put(MediaStore.MediaColumns.MIME_TYPE, mimeType)
                        put(MediaStore.MediaColumns.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS)
                    }
                    val uri = contentResolver.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, values)
                        ?: throw Exception("Could not create download file")
                    contentResolver.openOutputStream(uri)?.use { it.write(bytes) } ?: throw Exception("Could not write file")
                } else {
                    val dir = getExternalFilesDir(Environment.DIRECTORY_DOWNLOADS) ?: filesDir
                    val out = File(dir, safeName)
                    FileOutputStream(out).use { it.write(bytes) }
                }
                runOnUiThread { Toast.makeText(this@MainActivity, "Saved to Downloads: $safeName", Toast.LENGTH_LONG).show() }
                "OK"
            } catch (e: Exception) {
                runOnUiThread { Toast.makeText(this@MainActivity, "Download failed: ${e.message}", Toast.LENGTH_LONG).show() }
                "ERROR: ${e.message}"
            }
        }
    }
}
