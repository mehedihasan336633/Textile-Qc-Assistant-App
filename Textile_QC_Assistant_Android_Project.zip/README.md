# Textile QC Assistant Android project (updated)

Includes the Android WebView wrapper and web app. Features include roll-wise 4-point QC, process loss, GSM average/min/max from entered readings, photo selection/camera capture, CSV and XLSX report export to the Android Downloads folder, and local saved reports. OCR uses Tesseract.js CDN and requires internet; verify OCR text before production use.

Build using the GitHub Actions workflow in the repository.
