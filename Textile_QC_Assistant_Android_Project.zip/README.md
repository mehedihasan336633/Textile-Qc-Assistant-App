# Textile QC Assistant v1

## Included
- `www/`: installable PWA source.
- `android/`: Android Studio WebView wrapper project for generating an APK.
- 4-point roll calculations, weighted batch average, roll grades, CSV export, local saved reports, GSM/packing data capture, process-loss calculator.
- Multiple photo upload and OCR text extraction (Tesseract.js CDN; internet required for OCR).

## Important limitations
- OCR is draft text extraction only. Handwritten inspection tables need human verification; OCR does not reliably map every handwritten value into roll columns.
- Calculations and saved report data work locally in the browser/WebView. OCR library is loaded from CDN and therefore needs internet.
- Roll length estimate assumes the selected GSM applies to each roll. Use actual per-roll GSM if available.
- CSV export opens in Excel. Native `.xlsx` export can be added in a later build.

## Build APK
1. Open the `android` folder in Android Studio.
2. Let Gradle sync complete (Android SDK 35 and JDK 17 recommended).
3. Build > Build Bundle(s) / APK(s) > Build APK(s).
4. Android Studio outputs the debug APK under `android/app/build/outputs/apk/debug/`.

This is a buildable starter source project, not a precompiled/signed APK.
